console.log('sidebar');
alert('sidebar');
