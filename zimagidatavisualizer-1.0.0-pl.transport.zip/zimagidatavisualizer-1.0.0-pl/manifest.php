<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'fred' => '*',
      'Fred TinyMCE RTE' => '*',
      'Ace' => '*',
      'Fred Font Awesome 5 Icon Editor' => '*',
    ),
    'changelog' => 'Initial ',
    'readme' => 'Read me',
    'license' => 'None yet',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'abb1c3028a2480b201a9bdb2bf0fb682',
      'native_key' => 'abb1c3028a2480b201a9bdb2bf0fb682',
      'filename' => 'xPDOScriptVehicle/cb01c9c070225dfde320810c3ede4b15.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'bd4b87e0fd7688b8bfeef23bcf6ee224',
      'native_key' => 'bd4b87e0fd7688b8bfeef23bcf6ee224',
      'filename' => 'xPDOScriptVehicle/9f962d51f7ea29730e2e0e8639765a2a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'FredFileVehicle',
      'class' => 'FileVehicle',
      'guid' => '98848c7ffbfcc9f8e831a42f358cb5c5',
      'native_key' => '98848c7ffbfcc9f8e831a42f358cb5c5',
      'filename' => 'FileVehicle/0069a5d8e8977a260ec61d961a6a9624.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '1563a2fb0c82a9d74640f39ce4d05adb',
      'native_key' => '1563a2fb0c82a9d74640f39ce4d05adb',
      'filename' => 'xPDOScriptVehicle/bcc8ac19f2e0723066bce69a7031b464.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'FredTheme',
      'guid' => '2b12b95d8187c6dd05502688d5a7cab0',
      'native_key' => 2,
      'filename' => 'FredTheme/760dec5470e8eef9353f7883c3005db7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '265689fd4ee1088dca61ca7490541b0b',
      'native_key' => 'fred_theme_zimagi-data-visualizer',
      'filename' => 'modNamespace/49840f10a9bf4ab3294cf6cc9479571d.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modLexiconEntry',
      'guid' => '730ececa51d6b14b6799cc4cd88d6604',
      'native_key' => 4,
      'filename' => 'modLexiconEntry/f08ccc45dc59c1c510f7fdb98f32fac5.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'fd78bfe7becf3b5d6ccb42ea6d58e41d',
      'native_key' => 'fd78bfe7becf3b5d6ccb42ea6d58e41d',
      'filename' => 'xPDOScriptVehicle/8642a7b46cfea5064c4862b12ff74a32.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '51ba4824e82ae345f994ef7757343a1a',
      'native_key' => '51ba4824e82ae345f994ef7757343a1a',
      'filename' => 'xPDOScriptVehicle/577a4b69de7a77426bba22b0bfed218f.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '10d9e50a39a64c1685c0f9c197164066',
      'native_key' => '10d9e50a39a64c1685c0f9c197164066',
      'filename' => 'xPDOScriptVehicle/e24796ba827cbb64d53f3b58cb06cf31.vehicle',
    ),
  ),
);