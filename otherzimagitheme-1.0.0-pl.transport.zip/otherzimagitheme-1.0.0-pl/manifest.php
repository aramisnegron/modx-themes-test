<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'fred' => '*',
    ),
    'changelog' => 'Initial',
    'readme' => 'Read me',
    'license' => 'None',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '59c4e747898d285a5058aeecda2db32a',
      'native_key' => '59c4e747898d285a5058aeecda2db32a',
      'filename' => 'xPDOScriptVehicle/16d7aa5a2321eb3270e77386e4773fa2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd6551f4d3f039e84ec5d178f3da3aafb',
      'native_key' => 'd6551f4d3f039e84ec5d178f3da3aafb',
      'filename' => 'xPDOScriptVehicle/566d9d417ec0a06939316d2e513bfd7d.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a215f70680bdbd0d7b0bab15ebf03cf9',
      'native_key' => 'a215f70680bdbd0d7b0bab15ebf03cf9',
      'filename' => 'xPDOScriptVehicle/c040e0e6af9af3571726fb042a158d0e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'FredTheme',
      'guid' => '22525e94012941a7a219822c7e9d5766',
      'native_key' => 2,
      'filename' => 'FredTheme/324519157e14f9acaf747b3a0992456d.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'fda65a7208c7141f9e7ce722cecb7389',
      'native_key' => 'fda65a7208c7141f9e7ce722cecb7389',
      'filename' => 'xPDOScriptVehicle/d8c908a5cc31158d41cf883e71597722.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '85f65f98a46c1cedf1e9ededf9e65704',
      'native_key' => '85f65f98a46c1cedf1e9ededf9e65704',
      'filename' => 'xPDOScriptVehicle/557838211b1a66311b404b664f321b18.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'cccce96ae403433ae4832535c0d2a066',
      'native_key' => 'cccce96ae403433ae4832535c0d2a066',
      'filename' => 'xPDOScriptVehicle/c9973244b5960a7148a086682de22778.vehicle',
    ),
  ),
);